/*
\file:      DAOTests
\author:    Vincent Li
\purpose:   This is the DAO Tests to see if they work properly
*/

using System;
using Xunit;
using HelpdeskDAL;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CaseStudyTests
{
    public class DAOTests
    {
        [Fact]
        public void Employee_GetByEmail()
        {
            EmployeeDAOB4Repo dao = new EmployeeDAOB4Repo();
            Employees selectedEmp = dao.GetByMail("bs@abc.com");
            Assert.NotNull(selectedEmp);
        }

        [Fact]
        public void Employee_GetByIdTest()
        {
            EmployeeDAOB4Repo dao = new EmployeeDAOB4Repo();
            Employees selectedEmployees = dao.GetById(1);
            Assert.NotNull(selectedEmployees);
        }

        [Fact]
        public void Employee_GetAllTest()
        {
            EmployeeDAOB4Repo dao = new EmployeeDAOB4Repo();
            List<Employees> selectedEmployees = new List<Employees>();
            selectedEmployees = dao.GetAll();
            Assert.NotNull(selectedEmployees);
        }

        [Fact]
        public void Employee_AddTest()
        {
            EmployeeDAOB4Repo dao = new EmployeeDAOB4Repo();

            Employees newEmployee = new Employees();
            newEmployee.FirstName = "Vincent";
            newEmployee.LastName = "Li";
            newEmployee.PhoneNo = "(555)555-1234";
            newEmployee.Title = "Mr.";
            newEmployee.DepartmentId = 100; // need to increment by 100
            newEmployee.Email = "vl@email.com";

            dao.Add(newEmployee);

            Assert.True(newEmployee.Id > 0);
        }

        // old version
        //[Fact]
        //public void Employee_UpdateTest()
        //{
        //    EmployeeDAOB4Repo dao = new EmployeeDAOB4Repo();
        //    int rowsUpdated = -1;
        //    Employees selectedEmployees = dao.GetByLastName("Li");

        //    if (selectedEmployees != null)
        //    {
        //        string oldPhoneNo = selectedEmployees.PhoneNo;
        //        string newPhoneNo = oldPhoneNo == "519-555-1234" ? "555-555-5555" : "519-555-1234";
        //        selectedEmployees.PhoneNo = newPhoneNo;
        //        rowsUpdated = dao.Update(selectedEmployees);
        //    }

        //    Assert.True(rowsUpdated > 0);
        //}

        // updated for lab 8
        [Fact]
        public void Employee_UpdateTest()
        {
            EmployeeDAO dao = new EmployeeDAO();
            Employees selectedEmployee = dao.GetByLastName("Li");

            if (selectedEmployee != null)
            {
                string oldPhoneNo = selectedEmployee.PhoneNo;
                string newPhoneNo = oldPhoneNo == "519-555-1234" ? "555-555-5555" : "519-555-1234";
                selectedEmployee.PhoneNo = newPhoneNo;
            }

            Assert.True(dao.Update(selectedEmployee) == UpdateStatus.Ok); // ok indicates row is updated
        }

        [Fact]
        public void Employee_DeleteTest()
        {
            EmployeeDAOB4Repo dao = new EmployeeDAOB4Repo();
            int rowsDeleted = -1;
            Employees selectedEmployees = dao.GetByLastName("Li");

            if (selectedEmployees != null)
            {
                rowsDeleted = dao.Delete(selectedEmployees.Id);
            }
            Assert.True(rowsDeleted == 1); // make it equal 1 bc the code only deletes 1 row of data
        }

        // lab 8
        [Fact]
        public void Employee_ConcurrencyTest()
        {
            EmployeeDAO dao1 = new EmployeeDAO();
            EmployeeDAO dao2 = new EmployeeDAO();
            Employees selectedEmployee1 = dao1.GetByLastName("Li");
            Employees selectedEmployee2 = dao2.GetByLastName("Li");

            if (selectedEmployee1 != null)
            {
                string oldPhoneNo = selectedEmployee1.PhoneNo;
                string newPhoneNo = oldPhoneNo == "519-555-1234" ? "555-555-5555" : "519-555-1234";
                selectedEmployee1.PhoneNo = newPhoneNo;
                if (dao1.Update(selectedEmployee1) == UpdateStatus.Ok)
                {
                    // need to change the phone number to something else
                    selectedEmployee2.PhoneNo = "666-666-6666"; // hoping it fails so we know it works
                    Assert.True(dao2.Update(selectedEmployee2) == UpdateStatus.Stale);
                }
                else
                {
                    Assert.True(false);
                }
            }
        }
    }
}
