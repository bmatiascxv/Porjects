﻿/*
\file:      ViewModelTest
\author:    Vincent Li
\purpose:   This is the file that is used to test the viewmodel to see if it functions properly
*/
using System;
using Xunit;
using HelpdeskDAL;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using HelpdeskViewModels;

namespace CaseStudyTests
{
    public class ViewModelTests
    {
        [Fact]
        public void ViewModel_GetByMail()
        {
            EmployeeViewModel vm = new EmployeeViewModel { Email = "bs@abc.com" };
            //vm.Email = "bs@abc.com";
            vm.GetByMail();
            Assert.NotNull(vm.Firstname);
        }

        [Fact]
        public void ViewModel_GetByIdTest()
        {
            EmployeeViewModel vm = new EmployeeViewModel();
            vm.Id = 1;
            vm.GetById();
            Assert.NotNull(vm.Firstname);
        }

        [Fact]
        public void ViewModel_GetAllTest()
        {
            EmployeeViewModel vm = new EmployeeViewModel();
            var emps = vm.GetAll();
            Assert.True(emps.Count > 0);
        }

        [Fact]
        public void ViewModel_AddTest()
        {
            EmployeeViewModel vm = new EmployeeViewModel();

            vm.Firstname = "Vincent";
            vm.Lastname = "Li";
            vm.Phoneno = "(555)555-1234";
            vm.Title = "Mr.";
            vm.DepartmentId = 100;
            vm.Email = "vl@email.com";

            vm.Add();

            Assert.True(vm.Id > 0);
        }

        [Fact]
        public void ViewModel_UpdateTest()
        {
            EmployeeViewModel vm = new EmployeeViewModel { Email = "vl@email.com" };
            vm.GetByMail();

            vm.Phoneno = vm.Phoneno == "(555)555-5551" ? "(555)555-5552" : "(555)555-5551";

            int empUpdated = vm.Update();

            Assert.True(empUpdated > 0);
        }

        [Fact]
        public void ViewModel_DeleteTest()
        {
            EmployeeViewModel vm = new EmployeeViewModel();
            vm.Email = "vl@email.com";
            vm.GetByMail();
            Assert.True(vm.Delete() == 1);
        }
    }
}
