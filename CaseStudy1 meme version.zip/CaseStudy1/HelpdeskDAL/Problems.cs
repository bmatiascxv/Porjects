﻿/*
\file:      problem
\author:    Vincent Li
\purpose:   This is used as the problems the customers have
*/
using System;
using System.Collections.Generic;

namespace HelpdeskDAL
{
    public partial class Problems : HelpdeskEntity // changed for lab 8
    {
        //public int Id { get; set; }
        public string Description { get; set; }
        //public byte[] Timer { get; set; }
    }
}
