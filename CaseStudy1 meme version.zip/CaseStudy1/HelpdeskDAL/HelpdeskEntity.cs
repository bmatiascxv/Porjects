﻿/*
\file:      HelpdeskEntity
\author:    Vincent Li
\purpose:   This is the file that the things that use id or timer will inherit from
*/
using System.ComponentModel.DataAnnotations;

namespace HelpdeskDAL
{
    public class HelpdeskEntity
    {
        public int Id { get; set; }
        [Timestamp]
        public byte[] Timer { get; set; }
    }
}
