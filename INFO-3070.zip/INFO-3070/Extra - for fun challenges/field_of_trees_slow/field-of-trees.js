var App, BORDER, Material, Menu, MenuItem, MuiThemeProvider, NUM_TREES, PIXELS, RaisedButton, React, ReactDOM, Slider, TextField, _, darkBaseTheme, dom, f, getMuiTheme, injectTapEventPlugin, my_theme, say;

React = require('react');

ReactDOM = require('react-dom');

_ = require('lodash');

Material = require("material-ui");

f = React.createFactory;

Slider = f(Material.Slider);

TextField = f(Material.TextField);

RaisedButton = f(Material.RaisedButton);

Menu = f(Material.Menu);

MenuItem = f(Material.MenuItem);

darkBaseTheme = (require("material-ui/styles/baseThemes/lightBaseTheme"))["default"];

getMuiTheme = (require('material-ui/styles/getMuiTheme'))["default"];

MuiThemeProvider = (require('material-ui/styles/MuiThemeProvider'))["default"];

my_theme = getMuiTheme(darkBaseTheme);

injectTapEventPlugin = require("react-tap-event-plugin");

injectTapEventPlugin();

dom = React.DOM;

say = function(x) {
  return console.log(x);
};

PIXELS = 600;

NUM_TREES = 5;

BORDER = 10;

App = React.createClass({
  screen: function(n) {
    return BORDER + (n * this.state.pixels_per_square);
  },
  getInitialState: function() {
    return {
      size: 5,
      sizes: [5, 10, 20, 50, 100, 200, 300, 400, 500],
      v_lines: [],
      h_lines: [],
      pixels_per_square: 0,
      trees: [],
      solutions: [],
      thinking: false,
      tree_radius: 5
    };
  },
  childContextTypes: {
    muiTheme: React.PropTypes.object
  },
  getChildContext: function() {
    return {
      muiTheme: my_theme
    };
  },
  componentDidMount: function() {
    return this.new_problem(10);
  },
  new_problem: function(n) {
    this.resize_the_field(n);
    return this.place_trees(n);
  },
  resize_the_field: function(new_size) {
    var h_lines, j, k, ref, ref1, results, results1, v_lines;
    if (new_size == null) {
      throw new Error("new_size is not defined");
    }
    say("resize_problem : " + new_size);
    if (new_size > 200) {
      v_lines = [];
      h_lines = [];
    } else {
      v_lines = (function() {
        results = [];
        for (var j = 1, ref = new_size - 1; 1 <= ref ? j <= ref : j >= ref; 1 <= ref ? j++ : j--){ results.push(j); }
        return results;
      }).apply(this).map((function(_this) {
        return function(n) {
          return {
            x1: n,
            y1: 0,
            x2: n,
            y2: new_size
          };
        };
      })(this));
      h_lines = (function() {
        results1 = [];
        for (var k = 1, ref1 = new_size - 1; 1 <= ref1 ? k <= ref1 : k >= ref1; 1 <= ref1 ? k++ : k--){ results1.push(k); }
        return results1;
      }).apply(this).map((function(_this) {
        return function(n) {
          return {
            x1: 0,
            y1: n,
            x2: new_size,
            y2: n
          };
        };
      })(this));
    }
    return this.setState({
      size: new_size,
      v_lines: v_lines,
      h_lines: h_lines,
      trees: [],
      solutions: [],
      pixels_per_square: PIXELS / new_size,
      tree_radius: Math.floor(50 / Math.sqrt(new_size))
    });
  },
  place_trees: function(n) {
    var j, k, l, len, len1, results, t1, t2, trees;
    if (n > 2) {
      say("=============place trees : " + n + " x " + n);
      trees = (function() {
        results = [];
        for (var j = 1; 1 <= n ? j <= n : j >= n; 1 <= n ? j++ : j--){ results.push(j); }
        return results;
      }).apply(this).map((function(_this) {
        return function() {
          return {
            x: Math.floor(Math.random() * (n - 1)) + 1,
            y: Math.floor(Math.random() * (n - 1)) + 1
          };
        };
      })(this));
      for (k = 0, len = trees.length; k < len; k++) {
        t1 = trees[k];
        for (l = 0, len1 = trees.length; l < len1; l++) {
          t2 = trees[l];
          if (t2 !== t1) {
            if (t2.x === t1.x && t2.y === t1.y) {
              say("duplicte trees -- trying again...");
              return this.place_trees(n);
            }
          }
        }
      }
      say("placed " + trees.length + " trees ( might be duplicates )");
      return this.setState({
        trees: trees,
        solutions: []
      });
    } else {
      throw new Error("n must be 3 or more");
    }
  },
  solve_problem: function() {
    var solver;
    solver = require('./solver');
    this.setState({
      thinking: true
    });
    return setTimeout((function(_this) {
      return function() {
        var elapsed_ms, end_time, solutions, start_time;
        start_time = new Date();
        solutions = [solver.solve(_this.state.size, _this.state.trees)];
        end_time = new Date();
        elapsed_ms = end_time.getTime() - start_time.getTime();
        return _this.setState({
          thinking: false,
          solutions: solutions,
          elapsed_ms: elapsed_ms
        });
      };
    })(this));
  },
  render: function() {
    return dom.div({}, dom.table({}, dom.tbody({}, dom.tr({}, dom.td({
      style: {
        verticalAlign: 'top'
      }
    }, dom.h1({}, "Field of Trees"), dom.h2({}, this.state.size + " x " + this.state.size), dom.pre({}, "\nThe field is " + this.state.size + " x " + this.state.size + ".\nThere are " + this.state.size + " trees scattered around the field ( but not touching the edge ).\nYou want to build a house ( or a soccer field, or something ) without cutting down any trees.\nFind the largest rectangle ( by area ) that you can fit between the trees.\n\n"), dom.table({}, dom.tbody({}, dom.tr({}, dom.td({
      style: {
        verticalAlign: 'top'
      }
    }, Menu({
      value: this.state.size,
      onChange: (function(_this) {
        return function(event, size) {
          say("NEW PROBLEM!");
          return _this.new_problem(size);
        };
      })(this)
    }, this.state.sizes.map((function(_this) {
      return function(size) {
        return MenuItem({
          key: size,
          primaryText: "" + size + ' x ' + size,
          value: size
        });
      };
    })(this)))), dom.td({
      style: {
        verticalAlign: 'top'
      }
    }, dom.textarea({
      rows: 9,
      cols: 99,
      value: JSON.stringify({
        size: this.state.size,
        trees: this.state.trees,
        solution: this.state.solutions[0]
      }, null, 2),
      style: {
        height: '400px',
        width: '400px',
        overflow: 'scroll'
      }
    }))))), dom.br(), dom.br()), dom.td({
      style: {
        verticalAlign: 'top',
        minWidth: '525px'
      }
    }, dom.div({
      id: 'div-for-svg'
    }, dom.svg({
      width: PIXELS + (BORDER * 2),
      height: PIXELS + (BORDER * 2),
      border: "2px solid blue"
    }, _.flatten, dom.rect({
      x: this.screen(0),
      y: this.screen(0),
      width: PIXELS,
      height: PIXELS,
      fill: "lightgreen",
      opacity: 0.5,
      stroke: "gray",
      strokeWidth: 2
    }), (this.state.v_lines.concat(this.state.h_lines)).map((function(_this) {
      return function(line, i) {
        return dom.line({
          key: i,
          x1: _this.screen(line.x1),
          x2: _this.screen(line.x2),
          y1: _this.screen(line.y1),
          y2: _this.screen(line.y2),
          stroke: "gray",
          strokeWidth: 1
        });
      };
    })(this)), this.state.trees.map((function(_this) {
      return function(tree, i) {
        return dom.circle({
          key: i,
          cx: _this.screen(tree.x),
          cy: _this.screen(tree.y),
          r: _this.state.tree_radius,
          fill: "green"
        });
      };
    })(this)), this.state.solutions.map((function(_this) {
      return function(solution, i) {
        return dom.rect({
          key: i,
          x: _this.screen(solution.left),
          y: _this.screen(solution.top),
          width: _this.state.pixels_per_square * solution.width,
          height: _this.state.pixels_per_square * solution.height,
          stroke: "orange",
          strokeWidth: 3,
          fill: "yellow",
          opacity: 0.2
        });
      };
    })(this)), this.state.solutions.map((function(_this) {
      return function(solution, i) {
        return dom.text({
          key: i,
          textAnchor: 'middle',
          x: _this.screen((solution.left + solution.right) / 2),
          y: _this.screen((solution.top + solution.bottom) / 2),
          stroke: "brown",
          strokeWidth: 1
        }, "" + solution.width + " x " + solution.height + " = " + solution.area);
      };
    })(this)))), RaisedButton({
      label: 'SOLVE',
      primary: true,
      onClick: (function(_this) {
        return function() {
          return _this.solve_problem();
        };
      })(this)
    }), this.state.thinking ? dom.div({}, dom.h4({}, "Thinking.....")) : this.state.solutions.length > 0 ? dom.div({}, dom.h4({}, "Solved in " + this.state.elapsed_ms + " ms."), dom.pre({
      style: {
        color: 'brown'
      }
    }, JSON.stringify(this.state.solutions, null, 2))) : void 0)))));
  }
});

ReactDOM.render(React.createElement(App), document.getElementById('container-for-react-app'));
