var browserify, coffee, error_handler, gulp, jade, plumber, rename, source;

gulp = require('gulp');

coffee = require('gulp-coffee');

jade = require('gulp-jade');

plumber = require('gulp-plumber');

browserify = require('browserify');

source = require('vinyl-source-stream');

rename = require('gulp-rename');

error_handler = function(err) {
  return console.log(err.stack);
};

gulp.task('coffee', function() {
  return gulp.src('**/*.coffee').pipe(plumber({
    errorHandler: error_handler
  })).pipe(coffee({
    bare: true
  })).pipe(gulp.dest('.'));
});

gulp.task('jade', function() {
  return gulp.src('**/*.jade').pipe(plumber({
    errorHandler: error_handler
  })).pipe(jade({
    pretty: true
  })).pipe(gulp.dest('.'));
});

gulp.task('browserify', function() {
  return browserify("./field-of-trees.js").bundle().pipe(source("field-of-trees.js")).pipe(rename("bundle.js")).pipe(gulp.dest("."));
});

gulp.task('watch_coffee', function() {
  return gulp.watch('**/*.coffee', ['coffee', 'browserify']);
});

gulp.task('watch_jade', function() {
  return gulp.watch('**/*.jade', ['jade']);
});

gulp.task('default', ['coffee', 'jade', 'watch_coffee', 'watch_jade']);
