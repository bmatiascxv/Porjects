﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace XmlJson
{
    public class Dinner
    {
        [XmlAttribute]
        public int calories { get; set; }
        public Beverage drink { get; set; }
        public Pasta main { get; set; }

        //need empty constructor to serialize
        public Dinner() :
            this(1000, new Beverage(DrinkType.Alcoholic, ""), new Pasta(NoodleType.Spaghetti, Sauce.Alfredo, ""))
        {
            //void
        }

        public Dinner(int cal, Beverage d, Pasta m)
        {
            this.calories = cal;
            this.drink = d;
            this.main = m;
        }
    }

    public class Beverage
    {
        public DrinkType drinkType { get; set; }
        [XmlAttribute]
        public string name { get; set; }
        public Beverage() :
            this(DrinkType.Nonalcoholic, "")
        {
            //void
        }
        public Beverage(DrinkType t, string n)
        {
            this.drinkType = t;
            this.name = n;
        }
    }

    public class Pasta
    {
        public NoodleType noodle { get; set; }
        public Sauce sauce { get; set; }
        [XmlAttribute]
        public string name { get; set; }
        public Pasta() :
            this(NoodleType.Spaghetti, Sauce.Meaty, "")
        {
            //void
        }

        public Pasta(NoodleType nt, Sauce s, string n)
        {
            this.noodle = nt;
            this.sauce = s;
            this.name = n;
        }
    }

    public enum NoodleType
    {
        Spaghetti,
        Penne,
        Linguine,
        Spaetzle
    }

    public enum DrinkType
    {
        Alcoholic,
        Nonalcoholic
    }

    public enum Sauce
    {
        Meaty,
        Alfredo
    }

}
