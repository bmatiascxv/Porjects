﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XmlJson
{
    class Program
    {
        static void Main(string[] args)
        {
            //random object
            Dinner myDinner = new Dinner(5000, new Beverage(DrinkType.Alcoholic, "Tre Fontane"), new Pasta(NoodleType.Penne, Sauce.Meaty, "Spicy Penne"));

            //create a serializer to do all the work for us because we're lazy
            //have to tell the serializer what type of object it is going to be serializing for us
            System.Xml.Serialization.XmlSerializer writer =
            new System.Xml.Serialization.XmlSerializer(typeof(Dinner));

            //just some code to say where we're going to save it
            var path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "//dinner.xml";

            //create that path or overwrite it
            System.IO.FileStream file = System.IO.File.Create(path);

            //serialize our class to the file
            writer.Serialize(file, myDinner);

            //close the file or else memory leaks and the computer crashes
            file.Close();

            //generates this:

            //<?xml version="1.0"?>
            //<Dinner calories="5000" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
            //  <drink name="Tre Fontane">
            //    <drinkType>Alcoholic</drinkType>
            //  </drink>
            //  <main name="Spicy Penne">
            //    <noodle>Penne</noodle>
            //    <sauce>Meaty</sauce>
            //  </main>
            //</Dinner>

            //1) XML declaration:   <?xml version="1.0"?>
            //2) XML Element:       <Dinner></Dinner>  or  <drink></drink>
            //3) XML Attribute:     calories="5000" or   name="Spicy Penne"

            //Load xml from file using a file stream
            Console.WriteLine();
            Console.WriteLine("Load class from xml...");
            using (FileStream fileStream = new FileStream(path, FileMode.Open))
            {
                Dinner result = (Dinner)writer.Deserialize(fileStream);
                Console.WriteLine("Dinner: cal({0}), Pasta: {1}, Beverage: {2}", result.calories, result.main.name, result.drink.name);
            }

            //painfully create xml manually like a dirty co-op
            //Have to create the individual pieces and append them to each other step by step
            XmlDocument newDoc = new XmlDocument();

            XmlDeclaration dec = newDoc.CreateXmlDeclaration("1.0", null, null);
            newDoc.AppendChild(dec);

            //root node with attribute
            XmlElement root = newDoc.CreateElement("root");
            XmlAttribute att1 = newDoc.CreateAttribute("attr1");
            att1.InnerText = "Cake";
            root.Attributes.Append(att1);
            newDoc.AppendChild(root);

            //child node with non-attribute text
            XmlElement childNode = newDoc.CreateElement("childNode");
            childNode.InnerText = "child";
            root.AppendChild(childNode);

            path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "//manualfile.xml";
            file = System.IO.File.Create(path);
            newDoc.Save(file);

            //generates
            //<?xml version="1.0"?>
            //<root attr1="Cake">
            //  <childNode>child</childNode>
            //</root>

            //manually read a very large file :(
            XmlDocument doc = new XmlDocument();
            doc.Load("StarTrekXML.xml");

            //get main element
            XmlElement universe = doc.DocumentElement;

            XmlNodeList galaxies = universe.GetElementsByTagName("galaxy");

            int count = 0;
            foreach (XmlElement galaxy in galaxies)
            {
                XmlNodeList starSystems = galaxy.GetElementsByTagName("starSystem");

                foreach (XmlElement starSystem in starSystems)
                {
                    XmlNodeList moons = starSystem.GetElementsByTagName("moon");

                    foreach (XmlElement moon in moons)
                    {
                        count++;
                    }//end foreach moon
                }//end foreach starsystem
            }//en foreach galaxy

            Console.WriteLine("So many moons: {0}", count);

            //convert xml to json
            string json = JsonConvert.SerializeXmlNode(newDoc);

            //generates:
            //"{\"?xml\":{\"@version\":\"1.0\"},\"root\":{\"@attr1\":\"Cake\",\"childNode\":\"child\"}}"

            //convert it back
            XmlDocument convertDoc = (XmlDocument)JsonConvert.DeserializeXmlNode(json);
        }
    }
}
